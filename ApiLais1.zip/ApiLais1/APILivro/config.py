SQLALCHEMY_DATABASE_URI = 'mysql://root@localhost/livros'
SECRET_KEY = 'sua_chave_aqui'